import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbFeedbackManager {
  Database _feedbackdatabase;

  Future openDb() async {
    if (_feedbackdatabase == null)
    {
      print("8888888888 Feedbackdatabase is null");
      _feedbackdatabase = await openDatabase(
          join(await getDatabasesPath(), "feedbackdatabase.db"),
          version: 1, onCreate: (Database db, int version) async {
        await db.execute("CREATE TABLE feedback(fbid INTEGER PRIMARY KEY AUTOINCREMENT, statement TEXT, categoryid TEXT, categoryname TEXT)");
      });
      /* // start delete database
      var databasesPath = await getDatabasesPath();
      String path = join(databasesPath, 'feedbackdatabase.db');

// Delete the database
      await deleteDatabase(path);
      */ // end delete database
    } else {
      print("feedbackdatabase is not null ****");
      return _feedbackdatabase;
    }
  }

  Future<int> insertFeedback(Feedbackobject feedback) async {
    print('call feedback dbmanager insert ${feedback.fbid}');
    await openDb();
    return await _feedbackdatabase.insert('feedback', feedback.toMap());
  }

  Future<List<Feedbackobject>> getFeedbackList() async {
    await openDb();
    final List<Map<String, dynamic>> maps = await _feedbackdatabase.query('feedback');
    return List.generate(maps.length, (i){
      return Feedbackobject(
        fbid: maps[i]['fbid'],
        statement: maps[i]['statement'],
        categoryid: maps[i]['categoryid'],
        categoryname: maps[i]['categoryname'],

      );
    });

  }
  Future<int> updateFeedback(Feedbackobject feedback) async {
    await openDb();
    return await _feedbackdatabase.update(
        'feedback',
        feedback.toMap(),
        where: 'feedback.fbid = ?',
        whereArgs: [feedback.fbid]);

  }

  Future<int> deleteFeedback(Feedbackobject feedback) async
  {
    print('Delete function fff ${feedback.fbid}');
    await openDb();
    return _feedbackdatabase.delete('feedback', where: 'feedback.fbid = ?', whereArgs: [feedback.fbid]);
  }

}

class Feedbackobject {
  int fbid;
  String statement;
  String categoryid;
  String categoryname;
  Feedbackobject({@required this.fbid, @required this.statement, @required this.categoryid, @required this.categoryname});
  Map<String, dynamic> toMap(){
    return {'fbid': fbid, 'statement': statement, 'categoryid': categoryid, 'categoryname': categoryname};
  }
}
