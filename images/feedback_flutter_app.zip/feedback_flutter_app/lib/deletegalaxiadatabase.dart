import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DeleteGalaxiaDatabase {
  Database _galaxiadatabase;

  Future deleteDb() async {
    print('about to delete the db');
        // start delete database
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'galaxiadatabase.db');
    await deleteDatabase(path);
    print('database deleted');
    // end delete database

  }
}