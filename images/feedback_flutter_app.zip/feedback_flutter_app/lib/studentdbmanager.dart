import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbStudentManager {
  Database _galaxiadatabase;

  Future openDb() async {

    if (_galaxiadatabase == null) {
      _galaxiadatabase = await openDatabase(
          join(await getDatabasesPath(), "galaxiadatabase.db"),
          version: 1, onCreate: (Database db, int version) async {
        await db.execute(
            "CREATE TABLE IF NOT EXISTS tencontent(contid INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS tenfeedback(tenid INTEGER PRIMARY KEY AUTOINCREMENT, tenrecipientname TEXT, tenrecipientphone TEXT, tenrecipientid TEXT, tengroup TEXT, tengroupid TEXT, tengrouptopic TEXT, tencategory TEXT, tencategoryid TEXT, tenmessage TEXT, tenmessageid TEXT, tenstatement TEXT, tenstatementid TEXT, tensendername TEXT, tensenderid TEXT, tensenderphone TEXT, tentimestamp TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS student(stid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS feedback(fbid INTEGER PRIMARY KEY AUTOINCREMENT, statement TEXT, categoryid TEXT, categoryname TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS category(catid INTEGER PRIMARY KEY AUTOINCREMENT, categorystatement TEXT, externalcategoryid TEXT)");
      });
    }
    else {
      return _galaxiadatabase;
    }

  }

  Future<int> insertStudent(Student student) async {
    //print('call student dbmanager insert ${student.stid}');
    await openDb();
    return await _galaxiadatabase.insert('student', student.toMap());

  }
  Future<List<String>> getStudentAsString(String name) async {
    var dbClient = await openDb();

    var results = await dbClient.rawQuery('SELECT studentOption FROM student Where name = \'$name\'');

    return results.map((Map<String, dynamic> row) {
      return row["studentOption"] as String;
    }).toList();
  }
  Future<List<Student>> getStudentList() async {
    await openDb();
    final List<Map<String, dynamic>> maps = await _galaxiadatabase.query('student');
    return List.generate(maps.length, (i){
      return Student(
        stid: maps[i]['stid'],
        name: maps[i]['name'],
        phone: maps[i]['phone'],
      );
    });

  }
  Future<int> updateStudent(Student student) async {
    await openDb();
    return await _galaxiadatabase.update(
        'student',
        student.toMap(),
        where: 'student.stid = ?',
        whereArgs: [student.stid]);

  }

  Future<int> deleteStudent(Student student) async
  {
    //print('Delete function fff ${student.stid}');
    await openDb();
    return _galaxiadatabase.delete('student', where: 'student.stid = ?', whereArgs: [student.stid]);
  }

}

class Student {
  int stid = 0;
  String name;
  String phone;
  Student({@required this.name, @required this.phone, @required this.stid});
  Map<String, dynamic> toMap(){
    return {'name': name, 'phone': phone, 'stid': stid};
  }
}
