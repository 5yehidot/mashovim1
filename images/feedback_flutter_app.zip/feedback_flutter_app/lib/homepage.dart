import 'package:flutter/material.dart';
import 'feedbacklist.dart';
import '‏‏categorylist.dart';
import 'student_page.dart';
import 'content_page.dart';
import 'tenfeedback.dart';
import 'deletegalaxiadatabase_page.dart';

class HomePage extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold
      (
      appBar: AppBar(title: Text('משוב מקדם למידה'),),
      body: Center(child: Container(
        child: MyTenFeedbackListPage(),//MyFeedbackListPage(),
      )),
      drawer: Drawer
        (
        child: ListView
          (
          children: <Widget>
          [
            DrawerHeader(
              padding: EdgeInsets.all(0),
              child: Image.network('https://images.pexels.com/photos/2150/sky-space-dark-galaxy.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'),
            ),
            /*ListTile(
              leading: Icon(Icons.home),
              title: Text('משוב'),
            ),*/
            FlatButton(
              onPressed: () {
                print('Delete GalaxiaDB');
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DeleteGalaxiaDatabasePage()),
                );
              },
              child: ListTile(
                leading: Icon(Icons.note_add),
                title: Text('אתחל בסיס נתונים'),
              ),
            ),
            Divider(),
            FlatButton(
              onPressed: () {
                print('Feedback statements');
                //return FeedbackList Page();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyFeedbackListPage()),
                );
              },
              child: ListTile(
                leading: Icon(Icons.note_add),
                title: Text('הודעות משוב'),
              ),
            ),
            Divider(),
            FlatButton(
              onPressed: () {
                print('Categories');
                //return FeedbackList Page();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyCategoryListPage()),
                );
              },
              child: ListTile(
                leading: Icon(Icons.note_add),
                title: Text('קטגוריות משוב'),
              ),
            ),
            Divider(),
            FlatButton(
              onPressed: () {
                print('תלמידים');
                //return MyStudentPage();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyStudentPage()),
                );
              },
              child: ListTile(
                leading: Icon(Icons.person_add),
                title: Text('תלמידים'),
              ),
            ),
            Divider(),
            FlatButton(
              onPressed: () {
                print('נושאים');
                //return MyContentPage();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyContentPage()),
                );
              },
              child: ListTile(
                leading: Icon(Icons.content_paste),
                title: Text('נושאים'),
              ),
            )
          ],
        ),
      ),
    );
  }
}