import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbCategoryManager {
  Database _galaxiadatabase;

  Future openDb() async {
    if (_galaxiadatabase == null)
    {
      _galaxiadatabase = await openDatabase(
          join(await getDatabasesPath(), "galaxiadatabase.db"),
          version: 1, onCreate: (Database db, int version) async {
        // await db.execute("CREATE TABLE category(catid INTEGER PRIMARY KEY AUTOINCREMENT, categorystatement TEXT, externalcategoryid TEXT)");
        await db.execute("CREATE TABLE IF NOT EXISTS tencontent(contid INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT)");
        await db.execute("CREATE TABLE IF NOT EXISTS tenfeedback(tenid INTEGER PRIMARY KEY AUTOINCREMENT, tenrecipientname TEXT, tenrecipientphone TEXT, tenrecipientid TEXT, tengroup TEXT, tengroupid TEXT, tengrouptopic TEXT, tencategory TEXT, tencategoryid TEXT, tenmessage TEXT, tenmessageid TEXT, tenstatement TEXT, tenstatementid TEXT, tensendername TEXT, tensenderid TEXT, tensenderphone TEXT, tentimestamp TEXT)");
        await db.execute("CREATE TABLE IF NOT EXISTS student(stid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)");
        await db.execute("CREATE TABLE IF NOT EXISTS feedback(fbid INTEGER PRIMARY KEY AUTOINCREMENT, statement TEXT, categoryid TEXT, categoryname TEXT)");
        await db.execute("CREATE TABLE IF NOT EXISTS category(catid INTEGER PRIMARY KEY AUTOINCREMENT, categorystatement TEXT, externalcategoryid TEXT)");

      });
    } else {
      return _galaxiadatabase;
    }
  }

  Future<int> insertCategory(Categoryobject category) async {
    //print('call category dbmanager insert ${category.catid}');
    await openDb();
    return await _galaxiadatabase.insert('category', category.toMap());
  }

  Future<List<Categoryobject>> getCategoryList() async {
    await openDb();
    final List<Map<String, dynamic>> maps = await _galaxiadatabase.query('category');
    return List.generate(maps.length, (i){
      return Categoryobject(
        catid: maps[i]['catid'],
        categorystatement: maps[i]['categorystatement'],
        externalcategoryid: maps[i]['externalcategoryid'],

      );
    });

  }

    Future<int> updateCategory(Categoryobject category) async {
    await openDb();
    return await _galaxiadatabase.update(
        'category',
        category.toMap(),
        where: 'category.catid = ?',
        whereArgs: [category.catid]);

  }

  Future<int> deleteCategory(Categoryobject category) async
  {
    //print('Delete function fff ${category.catid}');
    await openDb();
    return _galaxiadatabase.delete('category', where: 'category.catid = ?', whereArgs: [category.catid]);
  }

}

class Categoryobject {
  int catid;
  String categorystatement;
  String externalcategoryid;

  Categoryobject({@required this.catid, @required this.categorystatement, @required this.externalcategoryid});
  Map<String, dynamic> toMap(){
    return {'catid': catid, 'categorystatement': categorystatement, 'externalcategoryid': externalcategoryid};
  }
}
