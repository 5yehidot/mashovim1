import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbContentManager {
  Database _galaxiadatabase;

  Future openDb() async {

    if (_galaxiadatabase == null) {
      _galaxiadatabase = await openDatabase(
          join(await getDatabasesPath(), "galaxiadatabase.db"),
          version: 1, onCreate: (Database db, int version) async {
        await db.execute(
            "CREATE TABLE IF NOT EXISTS tencontent(contid INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS tenfeedback(tenid INTEGER PRIMARY KEY AUTOINCREMENT, tenrecipientname TEXT, tenrecipientphone TEXT, tenrecipientid TEXT, tengroup TEXT, tengroupid TEXT, tengrouptopic TEXT, tencategory TEXT, tencategoryid TEXT, tenmessage TEXT, tenmessageid TEXT, tenstatement TEXT, tenstatementid TEXT, tensendername TEXT, tensenderid TEXT, tensenderphone TEXT, tentimestamp TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS student(stid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS feedback(fbid INTEGER PRIMARY KEY AUTOINCREMENT, statement TEXT, categoryid TEXT, categoryname TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS category(catid INTEGER PRIMARY KEY AUTOINCREMENT, categorystatement TEXT, externalcategoryid TEXT)");
      });
    }
    else {
      return _galaxiadatabase;
    }

  }

  Future<int> insertContent(Content content) async {
    //print('call content dbmanager insert ${content.contid}');
    await openDb();
    return await _galaxiadatabase.insert('content', content.toMap());

  }
  Future<List<String>> getContentAsString(String content) async {
    var dbClient = await openDb();

    var results = await dbClient.rawQuery('SELECT contentOption FROM content Where name = \'$content\'');

    return results.map((Map<String, dynamic> row) {
      return row["contentOption"] as String;
    }).toList();
  }
  Future<List<Content>> getContentList() async {
    await openDb();
    final List<Map<String, dynamic>> maps = await _galaxiadatabase.query('content');
    return List.generate(maps.length, (i){
      return Content(
        contid: maps[i]['contid'],
        content: maps[i]['content'],
      );
    });

  }
  Future<int> updateContent(Content content) async {
    await openDb();
    return await _galaxiadatabase.update(
        'content',
        content.toMap(),
        where: 'content.contid = ?',
        whereArgs: [content.contid]);

  }

  Future<int> deleteContent(Content content) async
  {
    await openDb();
    return _galaxiadatabase.delete('content', where: 'content.contid = ?', whereArgs: [content.contid]);
  }

}

class Content {
  int contid = 0;
  String content;
  Content({@required this.content, @required this.contid});
  Map<String, dynamic> toMap(){
    return {'content': content, 'contid': contid};
  }
}
