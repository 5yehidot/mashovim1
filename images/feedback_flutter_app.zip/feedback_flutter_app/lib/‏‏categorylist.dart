import 'dart:math';
import 'package:flutter/material.dart';
import 'categorydbmanager.dart';

class MyCategoryListPage extends StatefulWidget {
  @override
  _MyCategoryListPageState createState() => _MyCategoryListPageState();
}

class _MyCategoryListPageState extends State<MyCategoryListPage> {
  final DbCategoryManager categorydbmanager = DbCategoryManager();
  final _categorystatementController = TextEditingController();
  final _externalcategoryidController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  Categoryobject category;
  List<Categoryobject> categorylist;
  int updatecatIndex;

//  List<String> _categoryoptions = <String>['', 'ש1', 'ש2', 'ש3', 'ש4'];
//  String _categoryselected = '';
    String _categoryid;
  var rng = new Random();

  _loadCategories() async
  {
    // gets data from sqflite
    final loadCategories = await categorydbmanager.getCategoryList();
    int cLength = loadCategories.length;
    print(cLength);
    final _categoryid = '$cLength';
    print('מזהה קטגוריה cLength $_categoryid');

  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    //loadCategoryList();
    return Scaffold(
      appBar: AppBar(
        title: Text('רשימת קטגוריות'),
      ),
      body: Container(
        color: Colors.grey[100],
        height: double.infinity,
        width: double.infinity,
        child: ListView(children: <Widget>[
          Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(
                      left: 25.0, top: 8.0, bottom: 25.0, right: 25.0),
                    child: TextFormField(
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(

/*                    padding: EdgeInsets.only(left: 25.0, top: 8.0, right: 25.0),
                    child: FormField<String>(
                      builder: (FormFieldState<String> state) {
                        return InputDecorator(
                          decoration: InputDecoration(
                            icon: const Icon(Icons.category),
                            labelText: '                 קטגוריה',
                            labelStyle: TextStyle(color: Colors.purple, fontSize: 18, fontWeight:  FontWeight.bold),

                          ),
                          isEmpty: _categoryselected == '',
                          child: new DropdownButtonHideUnderline(
                            child: new DropdownButton<String>(
                              value: _categoryselected,
                              isDense: true,
                              onChanged: (String newValue) {
                                setState(() {
                                  _categorystatementController.text = newValue;
                                  _categoryselected = newValue;
                                  state.didChange(newValue);
                                });
                              },
                              items: _categoryoptions.map((String value) {
                                return new DropdownMenuItem<String>(
                                  value: value,
                                  child: new Text(value),
                                );
                              }).toList(),
                            ),
                          ),
                        );
                      },
                    ),
 */
                        labelText:
                        'קטגוריה                                                 ',
                        hintText: 'הקלד/י קטגוריה',
                        labelStyle: TextStyle(
                          color: Colors.purple,
                          fontWeight: FontWeight.bold)),
                        controller: _categorystatementController,
                        validator: (val) =>
                          val.isNotEmpty ? null : 'קטגוריה לא יכולה להשאר ריקה',
                      ),
                  ),
/*                  Padding(
                    padding: EdgeInsets.only(
                        left: 25.0, top: 8.0, bottom: 25.0, right: 25.0),
                    child: TextFormField(
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                          labelText:
                              'מספר מזהה קטגוריה                                                                              ',
                          hintText: 'הקלד/י מספר מזהה קטגוריה',
                          labelStyle: TextStyle(
                              color: Colors.purple,
                              fontWeight: FontWeight.bold)),
                      controller: _externalcategoryidController,
                      validator: (val) => val.isNotEmpty
                          ? null
                          : 'מזהה קטגוריה לא יכול להשאר ריק',
                    ),
                  ),
     */             RaisedButton(
                      textColor: Colors.white,
                      color: Colors.purple,
                      child: Container(
                          width: width * 0.95,
                          height: 80.0,
                          child: Text('עדכן', style: TextStyle(fontSize: 30.0),),
                          alignment: Alignment(0.0, 0.0),
                      ),

                      onPressed: () {
//                        _categoryid = _loadCategories();
                        _categoryid = (rng.nextInt(100)).toString();
                        print('מזהה קטגוריה מחושב$_categoryid');
                        _externalcategoryidController.text = _categoryid;
                        FocusScope.of(context).requestFocus(
                            new FocusNode()); // make soft keyboard disappeared
                        setState(() {
                          _submitCategory(context);
                          print('Item was added');
                        });
                      }),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      FutureBuilder(
                    future: categorydbmanager.getCategoryList(),
                    builder: (context, snapshot) {
                    //  if (snapshot.connectionState == ConnectionState.done) {
                      if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
                          categorylist = snapshot.data;
                          return ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount:
                                categorylist == null ? 0 : categorylist.length,
                            itemBuilder: (BuildContext context, int index) {
                              Categoryobject cat = categorylist[index];
                              print(cat.categorystatement);
                              return Card(
                                child: Row(
                                  children: <Widget>[
                                    Container(
                                        margin: const EdgeInsets.all(5.0),
                                        color: Colors.purple[100],
                                        width: width * 0.82,
                                        height: 60.0,
                                        child: FlatButton(
                                          // make a category card clickable
                                          onPressed: () {
                                            // Update input fields with current category statement and external category id if user clicks on a category card
                                            _categorystatementController.text =
                                                cat.categorystatement;
//                                            _externalcategoryidController.text = cat.externalcategoryid;

                                            category =
                                                cat; // Notify submitCategory that category is not null
                                            updatecatIndex =
                                                index; // Notify list builder which card needs update
                                          }, // onPressed
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                '${cat.categorystatement}',
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    color: Colors.blue),
                                              ),
                                              Text(
                                                'מזהה קטגוריה: ${cat.externalcategoryid}',
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    color: Colors.purple),
                                              ),
                                            ],
                                          ),
                                        )),
                                    /*IconButton(
                                      onPressed: () {
                                        // Update input fields with current category statement and external category id if user clicks on EDIT ICON
                                        _categorystatementController.text =
                                            cat.categorystatement;
                                        _externalcategoryidController.text =
                                            cat.externalcategoryid;

                                        category =
                                            cat; // Notify submitCategory that category is not null
                                        updatecatIndex =
                                            index; // Notify list builder which card needs update
                                      }, // onPressed
                                      icon: Icon(
                                        Icons.edit,
                                        color: Colors.blueAccent,
                                      ),
                                    ),
                                    */IconButton(
                                      onPressed: () {
                                        print(
                                            'onpressed call deleteCategory *** $index to be removed from database');
                                        category = cat;
                                        // category.id = index;
                                        // categorydbmanager.deleteCategory(index);
                                        // Delete category from categorydatabase
                                        categorydbmanager
                                            .deleteCategory(category)
                                            .then((catid) {
                                          setState(() {
                                            // refresh CategoryList cards;
                                            categorylist.removeAt(index);
                                            _categorystatementController.clear();
                                            _externalcategoryidController.clear();
                                            //print('setstate removeAt update list after category $index removed from list');
                                          }); // setState
                                        });
                                      }, // onPressed
                                      icon: Icon(
                                        Icons.delete,
                                        color: Colors.red,
                                      ),
                                    )
                                  ],
                                ),
                              );
                            },
                            // itemBuilder
                            reverse: true,
                          );
                      } // if
                      else {
                        if (snapshot.hasError) {
                          print('Error: ${snapshot.error}');
                        } else {
                          return CircularProgressIndicator();
                        } // else
                      }
                      return CircularProgressIndicator();

                    }, // builder
                      ), // futureBuilder
                    ], // widget
                  ),
                ],
              ), // column
          ) // Form
        ] // widget
        ), // ListView
      ),
    ); // scaffold
  } //widget build

// Either add category record or update category record
  void _submitCategory(BuildContext context) {
    if (_formKey.currentState.validate()) {
      if (category == null) {
        print("******category null Create a new category record"); // Create a new category record
        Categoryobject cat = Categoryobject(
            categorystatement: _categorystatementController.text,
            externalcategoryid: _externalcategoryidController.text);
        categorydbmanager.insertCategory(cat).then((id) => {
              // Insert new category record to the category database
              // and clear the input fields category statement and external category id
              _categorystatementController.clear(),
              _externalcategoryidController.clear(),
            });
      } else {
        print("******category NOT null");

        category.categorystatement = _categorystatementController.text;
        category.externalcategoryid = _externalcategoryidController.text;

        // Update category record in category database after it was edited by the user

        categorydbmanager.updateCategory(category).then((catid) => {
              setState(() {
                categorylist[updatecatIndex].categorystatement =
                    _categorystatementController.text;
                categorylist[updatecatIndex].externalcategoryid =
                    _externalcategoryidController.text;
              }),
              // Clear input fields
              _categorystatementController.clear(),
              _externalcategoryidController.clear(),
            });
        // Clear category to allow for new category submital
        category = null;
      } // end else category is not null
    } // if _formKey
  } // _submitCategory

/*  List<Widget> getFormWidget() {
    List<Widget> formWidget = new List();

    formWidget.add(new DropdownButton(
      hint: new Text('Select Category'),
      items: categoryList,
      value: _selectedCategory,
      onChanged: (value) {
        setState(() {
          _selectedCategory = value;
          print(value);
        });
      },
      isExpanded: true,
    ));

    return formWidget;
  }
*/
} //class _MyHomePageState
