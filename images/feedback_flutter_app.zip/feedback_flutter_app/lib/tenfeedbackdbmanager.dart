import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbTenFeedbackManager {
  Database _galaxiadatabase;

  Future openDb() async {
    if (_galaxiadatabase == null) {
      _galaxiadatabase = await openDatabase(
          join(await getDatabasesPath(), "galaxiadatabase.db"),
          version: 1, onCreate: (Database db, int version) async {
        await db.execute(
            "CREATE TABLE IF NOT EXISTS tencontent(contid INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS tenfeedback(tenid INTEGER PRIMARY KEY AUTOINCREMENT, tenrecipientname TEXT, tenrecipientphone TEXT, tenrecipientid TEXT, tengroup TEXT, tengroupid TEXT, tengrouptopic TEXT, tencategory TEXT, tencategoryid TEXT, tenmessage TEXT, tenmessageid TEXT, tenstatement TEXT, tenstatementid TEXT, tensendername TEXT, tensenderid TEXT, tensenderphone TEXT, tentimestamp TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS student(stid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS feedback(fbid INTEGER PRIMARY KEY AUTOINCREMENT, statement TEXT, categoryid TEXT, categoryname TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS category(catid INTEGER PRIMARY KEY AUTOINCREMENT, categorystatement TEXT, externalcategoryid TEXT)");
      });
    }
    else {
      return _galaxiadatabase;
    }
  }

  Future<int> insertTenFeedback(TenFeedbackobject tenfeedback) async {
    //print('call galaxiadatabase insert ${tenfeedback.tenmessage} ${tenfeedback.tencategoryname} ');
    await openDb();
    return await _galaxiadatabase.insert('tenfeedback', tenfeedback.toMap());
  }

  Future<List<TenFeedbackobject>> getTenFeedbackList() async {
    await openDb();
    final List<Map<String, dynamic>> maps = await _galaxiadatabase.query('tenfeedback');
    return List.generate(maps.length, (i){
      return TenFeedbackobject(
        tenid: maps[i]['tenid'],
        tenrecipientname: maps[i]['tenrecipientname'],
        tenrecipientphone: maps[i]['tenrecipientname'],
        tenrecipientid: maps[i]['tenrecipientid'],
        tengroup: maps[i]['tengroup'],
        tengroupid: maps[i]['tengroupid'],
        tengrouptopic: maps[i]['tengrouptopic'],
        tencategory: maps[i]['tencategory'],
        tencategoryid: maps[i]['tencategoryid'],
        tenmessage: maps[i]['tenmessage'],
        tenmessageid: maps[i]['tenmessageid'],
        tenstatement: maps[i]['tenstatement'],
        tenstatementid: maps[i]['tenstatementid'],
        tensendername: maps[i]['tensendername'],
        tensenderphone: maps[i]['tensenderphone'],
        tentimestamp: maps[i]['tentimestamp'],

      );
    });

  }
  Future<int> updateTenFeedback(TenFeedbackobject tenfeedback) async {
    await openDb();
    return await _galaxiadatabase.update(
        'tenfeedback',
        tenfeedback.toMap(),
        where: 'tenfeedback.tenid = ?',
        whereArgs: [tenfeedback.tenid]);

  }

  Future<int> deleteTenFeedback(TenFeedbackobject tenfeedback) async
  {
    //print('Delete function fff ${tenfeedback.tenid}');
    await openDb();
    return _galaxiadatabase.delete('tenfeedback', where: 'tenfeedback.tenid = ?', whereArgs: [tenfeedback.tenid]);
  }

}

class TenFeedbackobject {
  int tenid;
  String tenrecipientname;
  String tenrecipientphone;
  String tenrecipientid;
  String tengroup;
  String tengroupid;
  String tengrouptopic;
  String tencategory;
  String tencategoryid;
  String tenmessage;
  String tenmessageid;
  String tenstatement;
  String tenstatementid;
  String tensendername;
  String tensenderid;
  String tensenderphone;
  String tentimestamp;

  TenFeedbackobject({@required this.tenid, @required this.tenrecipientname, @required this.tenrecipientphone, @required this.tenrecipientid, @required this.tengroup, @required this.tengroupid, @required this.tengrouptopic, @required this.tencategory, @required this.tencategoryid, @required this.tenmessage, @required this.tenmessageid, @required this.tenstatement, @required this.tenstatementid, @required this.tensendername, @required this.tensenderid, @required this.tensenderphone, @required this.tentimestamp});
  Map<String, dynamic> toMap(){
    return {'tenid': tenid, 'tenrecipientname': tenrecipientname, 'tenrecipientphone': tenrecipientphone, 'tenrecipientid': tenrecipientid, 'tengroup': tengroup, 'tengroupid': tengroupid, 'tengrouptopic': tengrouptopic, 'tencategory': tencategory, 'tencategoryid': tencategoryid, 'tenmessage': tenmessage, 'tenmessageid': tenmessageid, 'tenstatement': tenstatement, 'tenstatementid': tenstatementid, 'tensendername': tensendername, 'tensenderid': tensenderid, 'tensenderphone': tensenderphone, 'tentimestamp': tentimestamp};
  }
}
