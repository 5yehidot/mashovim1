import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbCategoryManager {
  Database _categorydatabase;

  Future openDb() async {
    if (_categorydatabase == null)
    {
      print("8888888888 Categorydatabase is null");
      _categorydatabase = await openDatabase(
          join(await getDatabasesPath(), "categorydatabase.db"),
          version: 1, onCreate: (Database db, int version) async {
        await db.execute("CREATE TABLE category(catid INTEGER PRIMARY KEY AUTOINCREMENT, categorystatement TEXT, externalcategoryid TEXT)");
      });
      /* // start delete database
      var databasesPath = await getDatabasesPath();
      String path = join(databasesPath, 'categorydatabase.db');

// Delete the database
      await deleteDatabase(path);
      */ // end delete database
    } else {
      print("categorydatabase is not null ****");
      return _categorydatabase;
    }
  }

  Future<int> insertCategory(Categoryobject category) async {
    print('call category dbmanager insert ${category.catid}');
    await openDb();
    return await _categorydatabase.insert('category', category.toMap());
  }

  Future<List<Categoryobject>> getCategoryList() async {
    await openDb();
    final List<Map<String, dynamic>> maps = await _categorydatabase.query('category');
    return List.generate(maps.length, (i){
      return Categoryobject(
        catid: maps[i]['catid'],
        categorystatement: maps[i]['categorystatement'],
        externalcategoryid: maps[i]['externalcategoryid'],

      );
    });

  }
  Future<int> updateCategory(Categoryobject category) async {
    await openDb();
    return await _categorydatabase.update(
        'category',
        category.toMap(),
        where: 'category.catid = ?',
        whereArgs: [category.catid]);

  }

  Future<int> deleteCategory(Categoryobject category) async
  {
    print('Delete function fff ${category.catid}');
    await openDb();
    return _categorydatabase.delete('category', where: 'category.catid = ?', whereArgs: [category.catid]);
  }

}

class Categoryobject {
  int catid;
  String categorystatement;
  String externalcategoryid;

  Categoryobject({@required this.catid, @required this.categorystatement, @required this.externalcategoryid});
  Map<String, dynamic> toMap(){
    return {'catid': catid, 'categorystatement': categorystatement, 'externalcategoryid': externalcategoryid};
  }
}
