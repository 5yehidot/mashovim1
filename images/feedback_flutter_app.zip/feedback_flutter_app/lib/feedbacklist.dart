import 'package:flutter/material.dart';
import 'package:share/share.dart';
import 'creategalaxiadatabase.dart';

import 'categorydbmanager.dart';
import 'feedbackdbmanager.dart';

class MyFeedbackListPage extends StatefulWidget {
  @override
  _MyFeedbackListPageState createState() => _MyFeedbackListPageState();
}

class _MyFeedbackListPageState extends State<MyFeedbackListPage> {
  final DbFeedbackManager feedbackdbmanager = DbFeedbackManager();
  final DbCategoryManager categorydbmanager = DbCategoryManager();
  final _statementController = TextEditingController();
  final _categoryidController = TextEditingController();
  final _categorynameController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  Feedbackobject feedback;
  List<Feedbackobject> feedbacklist;
  int updatefbIndex;

  // List<String> _categorylist = <String>[''];
 // String _categoryselected = '';

  // List<String> _categoryidoptions = <String>['', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  // String _categoryidselected = '';
  /*Widget buildcategorylist(BuildContext context) {
  return FutureBuilder(
  future: categorydbmanager.getCategoryList(),
  builder: (context, snapshot) {
    if (snapshot.connectionState == ConnectionState.done &&
        snapshot.data != null) {
      _categoryoptions1 = snapshot.data;
      print(_categoryoptions1);
    }
    else {
      if (snapshot.hasError) {
        print('Error: ${snapshot.error}');
      } else {
        return CircularProgressIndicator();
      } // else
    }
    return CircularProgressIndicator();
  }
    );
  }

*/
  List<String> _categorylist = <String>[''];
  String _categoryselected = '';

  List<String> _feedbacklist = <String>[''];
  String _feedbackselected = '';

  List<String> _studentnamelist = <String>[''];
  String _recipientnameselected = '';

//  @override
  /*initState()
  {
    super.initState();
    // when loading your widget for the first time, loads recipient student names from sqflite
    _loadCategories();
    _loadFeedbackStatements();
    _loadStudentnames();

  }
*/
  _loadCategories() async
  {
    // gets data from sqflite
    final loadCategories = await categorydbmanager.getCategoryList();
    int cLength = loadCategories.length;
    int clLength = _categorylist.length;
    if (clLength>1) {_categorylist.removeRange(0,clLength-1);} else {print('רשימת קטגוריות באורך 1');}
    print('רשימת קטגוריות');
    print(_categorylist);
    for (var j=0; j<cLength; j++)
    {
      print(loadCategories[j].categorystatement);
      _categorylist.insert(j, loadCategories[j].categorystatement);
    }
  }

    @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;



    return Scaffold(
      appBar: AppBar(
        title: Text('רשימת הודעות משוב'),
      ),
      body: Container(
        color: Colors.grey[100],
        height: double.infinity,
        width: double.infinity,
        child: ListView(children: <Widget>[
          Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(left: 25.0, top: 8.0, right: 25.0),
                  child: TextFormField(
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                        labelText:
                            'משוב                                                   ',
                        hintText: 'הקלד/י הודעת משוב',
                        labelStyle: TextStyle(
                            color: Colors.purple, fontSize: 18, fontWeight: FontWeight.bold, )),
                    controller: _statementController,
                    validator: (val) =>
                        val.isNotEmpty ? null : 'הודעה לא יכולה להשאר ריקה',
                  ),
                ),
/*
                Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, top: 8.0, bottom: 25.0, right: 25.0),
                    child: FormField<String>(
                      builder: (FormFieldState<String> state) {
                        return InputDecorator(
                          decoration: InputDecoration(
                            icon: const Icon(Icons.vpn_key),
                            labelText: '                    מזהה קטגוריה',
                            labelStyle: TextStyle(color: Colors.purple, fontSize: 18, fontWeight:  FontWeight.bold),

                          ),
                          isEmpty: _categoryidselected == '',
                          child: new DropdownButtonHideUnderline(
                            child: new DropdownButton<String>(
                              value: _categoryidController.text,
                              isDense: true,
                              onChanged: (String newValue) {
                                setState(() {
                                  _categoryidController.text = newValue;
                                  _categoryidselected = newValue;
                                  state.didChange(newValue);
                                });
                                print(_categoryidselected);
                              },
//    items: _categoryidoptions.map((String value) {
                              items: _categoryidoptions.map((String value) {
                                return new DropdownMenuItem<String>(
                                  value: value,
                                  child: new Text(value),
                                );
                              }).toList(),
                            ),
                          ),
                        );
                      },
                    ),
                    */
/*TextFormField(
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                          labelText:
                              'מספר מזהה קטגוריה                                                                              ',
                          hintText: 'הקלד/י מספר מזהה קטגוריה',
                          labelStyle: TextStyle(
                              color: Colors.purple, fontWeight: FontWeight.bold)),
                      controller: _categoryidController,
                      validator: (val) => val.isNotEmpty
                          ? null
                          : 'מזהה קטגוריה לא יכול להשאר ריק',
                    ),
                  *//*

                ),
*/
                Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, top: 8.0, bottom: 25.0, right: 25.0),
                  child: FormField<String>(
                    builder: (FormFieldState<String> state) {
                      _loadCategories();

                      return InputDecorator(
                        decoration: InputDecoration(
                          icon: const Icon(Icons.category),
                          labelText: '                         קטגוריה',
                          labelStyle: TextStyle(color: Colors.purple, fontSize: 18, fontWeight:  FontWeight.bold),

                        ),
                        isEmpty: _categoryselected == '',
                        child: new DropdownButtonHideUnderline(
                          child: new DropdownButton<String>(
                            value: _categorynameController.text,
                            isDense: true,
                            onChanged: (String newValue) {
                              setState(() {
                                _categorynameController.text = newValue;
                                _categoryselected = newValue;
                                state.didChange(newValue);
                              });
                            },
                            items: _categorylist.map((String value) {
                              return new DropdownMenuItem<String>(
                                value: value,
                                child: new Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                      );
                    },
                  ),
                  /*TextFormField(
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                        labelText:
                            'קטגוריה                                                                              ',
                        hintText: 'הקלד/י שם קטגוריה',
                        labelStyle: TextStyle(
                            color: Colors.purple, fontWeight: FontWeight.bold)),
                    controller: _categorynameController,
                    validator: (val) =>
                        val.isNotEmpty ? null : 'שם קטגוריה לא יכול להשאר ריק',
                  ),

                   */
                ),
                RaisedButton(
                    textColor: Colors.white,
                    color: Colors.purple,
                    child: Container(
                        width: width * 0.95,
                        height: 80.0,
                        child: Text('עדכן', style: TextStyle(fontSize: 30.0),),
                        alignment: Alignment(0.0, 0.0),
                ),
                    onPressed: () {
                      FocusScope.of(context).requestFocus(
                          new FocusNode()); // make soft keyboard disappeared
                      //Share.share(_statementController.text);

                      setState(() {
                        print('Item was added');
                        _submitFeedback(context);
                      });
                    }),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    FutureBuilder(
                      future: feedbackdbmanager.getFeedbackList(),
                      builder: (context, snapshot) {
                        //if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
                        if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
                          feedbacklist = snapshot.data;
                          return ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount:
                                feedbacklist == null ? 0 : feedbacklist.length,
                            itemBuilder: (BuildContext context, int index) {
                              Feedbackobject fb = feedbacklist[index];
                              //print(fb.statement);
                              return Card(
                                child: Row(
                                  children: <Widget>[
                                    Container(
                                        margin: const EdgeInsets.all(5.0),
                                        color: Colors.purple[100],
                                        width: width * 0.82,
                                        height: 120.0,
                                        child: FlatButton(
                                          // make a feedback card clickable
                                          onPressed: () {
                                            // Update input fields with current statement, categoryid and categoryname if user clicks on a feedback card
                                            _statementController.text =
                                                fb.statement;
                                            _categoryidController.text =
                                                fb.categoryid;
                                            _categorynameController.text =
                                                fb.categoryname;

                                            feedback =
                                                fb; // Notify submitFeedback that feedback is not null
                                            updatefbIndex =
                                                index; // Notify list builder which card needs update
                                          }, // onPressed
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                '${fb.statement}',
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    color: Colors.blue),
                                              ),
                                              /*Text(
                                                '${fb.categoryname}',
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    color: Colors.blue),
                                              ),*/
                                            ],
                                          ),
                                        )),
                                    /*IconButton(
                                      onPressed: () {
                                        // Update input fields with current statement, category id and category if user clicks on EDIT ICON
                                        _statementController.text =
                                            fb.statement;
                                        _categoryidController.text =
                                            fb.categoryid;
                                        _categorynameController.text =
                                            fb.categoryname;
                                        feedback =
                                            fb; // Notify submitFeedback that feedback is not null
                                        updatefbIndex =
                                            index; // Notify list builder which card needs update
                                      }, // onPressed
                                      icon: Icon(
                                        Icons.edit,
                                        color: Colors.blueAccent,
                                      ),
                                    ),*/
                                    IconButton(
                                      onPressed: () {
                                        //print('onpressed call deleteFeedback *** $index to be removed from feedback table in galaxia database');
                                        feedback = fb;
                                        // Delete feedback record from feedback table in galaxia database
                                        feedbackdbmanager
                                            .deleteFeedback(feedback)
                                            .then((fbid) {
                                          setState(() {
                                            // refresh Feedback List cards;
                                            feedbacklist.removeAt(index);
                                            _statementController.clear();
                                            _categoryidController.clear();
                                            _categorynameController.clear();
                                            //print('setstate removeAt update list after feedback $index removed from list');
                                          }); // setState
                                        });
                                      }, // onPressed
                                      icon: Icon(
                                        Icons.delete,
                                        color: Colors.red,
                                      ),
                                    )
                                  ],
                                ),
                              );
                            }, // itemBuilder
                            reverse: true,
                          );
                        } // if
                        else {
                          if (snapshot.hasError) {
                            print('Error: ${snapshot.error}');
                          } else {
                            return CircularProgressIndicator();
                          } // else
                        }
                        return CircularProgressIndicator();

                      }, // builder
                    ), // futureBuilder
                  ], // widget
                ),
              ],
            ), // column
          ) // Form
        ] // widget
            ), // ListView
      ),
    ); // scaffold
  } //widget build

// Either add feedback record or update feedback record
  void _submitFeedback(BuildContext context) {
    if (_formKey.currentState.validate()) {
      if (feedback == null) {
        //print("******feedback null"); // Create a new feedback record

    Feedbackobject fb = Feedbackobject(
            statement: _statementController.text,
            categoryid: _categoryidController.text,
            categoryname: _categorynameController.text);
        //print("******feedback null"); // Create a new feedback record
        feedbackdbmanager.insertFeedback(fb).then((fbid) => {
              // Insert new feedback record to the feedback table in galaxia database
              // and clear the input fields statement, category id and category name
              _statementController.clear(),
              _categoryidController.clear(),
              _categorynameController.clear(),
            });
      } else {
        //print("******feedback NOT null");

        feedback.statement = _statementController.text;
        feedback.categoryid = _categoryidController.text;
        feedback.categoryname = _categorynameController.text;
        //print(feedback);

        // Update feedback record in feedback table in galaxia database after it was edited by the user

        feedbackdbmanager.updateFeedback(feedback).then((fbid) => {
              setState(() {
                feedbacklist[updatefbIndex].statement =
                    _statementController.text;
                feedbacklist[updatefbIndex].categoryid =
                    _categoryidController.text;
                feedbacklist[updatefbIndex].categoryname =
                    _categorynameController.text;
              }),
              // Clear input fields
              _statementController.clear(),
              _categoryidController.clear(),
              _categorynameController.clear(),
            });
        // Clear feedback to allow for new feedback submit
        feedback = null;
      } // end else feedback is not null
    } // if _formKey
  } // _submitFeedback
} //class
