import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbFeedbackManager {
  Database _galaxiadatabase;


  Future openDb() async {
    if (_galaxiadatabase == null) {
      /*var databasesPath = await getDatabasesPath();
      String path = join(databasesPath, 'galaxiadatabase.db');
      await deleteDatabase(path);
      print('database deleted');*/
      _galaxiadatabase = await openDatabase(
          join(await getDatabasesPath(), "galaxiadatabase.db"),
          version: 1, onCreate: (Database db, int version) async {
        await db.execute(
            "CREATE TABLE IF NOT EXISTS tencontent(contid INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS tenfeedback(tenid INTEGER PRIMARY KEY AUTOINCREMENT, tenrecipientname TEXT, tenrecipientphone TEXT, tenrecipientid TEXT, tengroup TEXT, tengroupid TEXT, tengrouptopic TEXT, tencategory TEXT, tencategoryid TEXT, tenmessage TEXT, tenmessageid TEXT, tenstatement TEXT, tenstatementid TEXT, tensendername TEXT, tensenderid TEXT, tensenderphone TEXT, tentimestamp TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS student(stid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS feedback(fbid INTEGER PRIMARY KEY AUTOINCREMENT, statement TEXT, categoryid TEXT, categoryname TEXT)");
        await db.execute(
            "CREATE TABLE IF NOT EXISTS category(catid INTEGER PRIMARY KEY AUTOINCREMENT, categorystatement TEXT, externalcategoryid TEXT)");
      });
    }
    else {
      return _galaxiadatabase;
    }
  }


  Future<int> insertFeedback(Feedbackobject feedback) async {
    //print('call galaxiadatabase insert ${feedback.statement} ${feedback.categoryname} ');
    await openDb();
    return await _galaxiadatabase.insert('feedback', feedback.toMap());
  }

  Future<List<Feedbackobject>> getFeedbackList() async {
    await openDb();
    final List<Map<String, dynamic>> maps = await _galaxiadatabase.query('feedback');
    return List.generate(maps.length, (i){
      return Feedbackobject(
        fbid: maps[i]['fbid'],
        statement: maps[i]['statement'],
        categoryid: maps[i]['categoryid'],
        categoryname: maps[i]['categoryname'],

      );
    });


  }
  Future<int> updateFeedback(Feedbackobject feedback) async {
    await openDb();
    return await _galaxiadatabase.update(
        'feedback',
        feedback.toMap(),
        where: 'feedback.fbid = ?',
        whereArgs: [feedback.fbid]);

  }

  Future<int> deleteFeedback(Feedbackobject feedback) async
  {
    //print('Delete function fff ${feedback.fbid}');
    await openDb();
    return _galaxiadatabase.delete('feedback', where: 'feedback.fbid = ?', whereArgs: [feedback.fbid]);
  }

}

class Feedbackobject {
  int fbid;
  String statement;
  String categoryid;
  String categoryname;
  Feedbackobject({@required this.fbid, @required this.statement, @required this.categoryid, @required this.categoryname});
  Map<String, dynamic> toMap(){
    return {'fbid': fbid, 'statement': statement, 'categoryid': categoryid, 'categoryname': categoryname};
  }
}
