import 'package:flutter/material.dart';
import 'deletegalaxiadatabase.dart';

class DeleteGalaxiaDatabasePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    DeleteGalaxiaDatabase();
    return _galaxiadatabase;
  }
}
