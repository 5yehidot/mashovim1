import 'package:flutter/material.dart';
import 'contentdbmanager.dart';

class MyContentPage extends StatefulWidget {
  @override
  _MyContentPageState createState() => _MyContentPageState();
}

class _MyContentPageState extends State<MyContentPage> {
  final DbContentManager contentdbmanager = DbContentManager();
  final _contentController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  Content content;
  List<Content> contentlist;
  int updateIndex;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('רשימת נושאים'),
      ),
      body: Container(
        color: Colors.grey[100],
        height: double.infinity,
        width: double.infinity,
        child: ListView(children: <Widget>[
          Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(left: 25.0, top: 8.0, right: 25.0),
                  child: TextFormField(
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                        labelText:
                        'נושא השיעור                                                 ',
                        hintText: 'הקלדת נושא',
                        labelStyle: TextStyle(
                            color: Colors.purple, fontSize: 18, fontWeight: FontWeight.bold)),
                    controller: _contentController,
                    validator: (val) =>
                    val.isNotEmpty ? null : 'נושא לא יכול להשאר ריק',
                  ),
                ),

                RaisedButton(
                    textColor: Colors.white,
                    color: Colors.purple,
                    child: Container(
                      width: width * 0.95,
                      height: 80,
                      child: Text('עדכן', style: TextStyle(fontSize: 30.0),),
                      alignment: Alignment(0.0, 0.0),
                    ),


                    onPressed: () {
                      FocusScope.of(context).requestFocus(
                          new FocusNode()); // make soft keyboard disappeared
                      setState(() {
                        print('Item was added');
                        _submitContent(context);
                      });

                    }),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    FutureBuilder(
                      future: contentdbmanager.getContentList(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
                          contentlist = snapshot.data;
                          return ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: contentlist == null ? 0 : contentlist.length,
                            itemBuilder: (BuildContext context, int index) {
                              Content st = contentlist[index];
                              print(st.content);
                              return Card(
                                child: Row(
                                  children: <Widget>[
                                    Container(
                                        margin: const EdgeInsets.all(5.0),
                                        color: Colors.purple[100],
                                        width: width * 0.82,
                                        height: 60.0,
                                        child: FlatButton(
                                          // make a student card clickable
                                          onPressed: () {
                                            // Update input fields with current name and phone if user clicks on a student card
                                            _contentController.text = st.content;
                                            content =
                                                st; // Notify submitstudent that student is not null
                                            updateIndex =
                                                index; // Notify list builder which card needs update
                                          }, // onPressed
                                          child: Column(
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                'שם: ${st.content}',
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    color: Colors.blue),
                                              ),
                                            ],
                                          ),
                                        )),
                                    /*IconButton(
                                        onPressed: () {
                                          // Update input fields with current name and phone if user clicks on EDIT ICON
                                          _nameController.text = st.name;
                                          _phoneController.text = st.phone;
                                          student =
                                              st; // Notify submitstudent that student is not null
                                          updateIndex =
                                              index; // Notify list builder which card needs update
                                        }, // onPressed
                                        icon: Icon(
                                          Icons.edit,
                                          color: Colors.blueAccent,
                                        ),
                                      ),
                                      */IconButton(
                                      onPressed: () {
                                        //print('onpressed call deleteStudent *** $index to be removed from database');
                                        content = st;
                                        // student.stid = index;
                                        // studentdbmanager.deleteStudent(index);
                                        // Delete student from student table in galaxia database
                                        contentdbmanager
                                            .deleteContent(content)
                                            .then((contid) {
                                          setState(() {
                                            // refresh ContentList cards;
                                            contentlist.removeAt(index);
                                            _contentController.clear();
                                          }); // setState
                                        });
                                      }, // onPressed
                                      icon: Icon(
                                        Icons.delete,
                                        color: Colors.red,
                                      ),
                                    )
                                  ],
                                ),
                              );
                            }, // itemBuilder
                            reverse: true,
                          );
                        } // if
                        else {
                          if (snapshot.hasError) {
                            print('Error: ${snapshot.error}');
                          } else {
                            return CircularProgressIndicator();
                          } // else
                        }
                        return CircularProgressIndicator();

                      }, // builder
                    ), // futureBuilder
                  ], // widget
                ),
              ],
            ), // column
          ) // Form
        ] // widget
        ), // ListView
      ),
    ); // scaffold
  } //widget build
// Either add student record or update student record
  void _submitContent(BuildContext context) {
    if (_formKey.currentState.validate()) {
      if (content == null) {
        Content st =
        Content(content: _contentController.text);
        contentdbmanager.insertContent(st).then((stid) => {
          // Insert new student record to the content table in galaxia database
          // and clear the input fields content
          _contentController.clear(),
        });
      } else {

        content.content = _contentController.text;
        // Update content record in content table in galaxia database after it was edited by the user

        contentdbmanager.updateContent(content).then((stid) => {
          setState(() {
            contentlist[updateIndex].content = _contentController.text;
          }),
          // Clear input fields
          _contentController.clear(),
        });
        // Clear student to allow for new student submital
        content = null;
      } // end else student is not null
    } // if _formKey
  } // _submitStudent
} //class _MyHomePageState
