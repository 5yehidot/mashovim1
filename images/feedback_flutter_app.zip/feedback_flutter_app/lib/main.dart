import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

/*import 'feedbacklist.dart';
import '‏‏categorylist.dart';
import 'student_page.dart';
*/
import 'creategalaxiadatabase.dart';
import 'homepage.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Provider(
      create: (_) async => CreateGalaxiaDatabase(),
      child: MaterialApp(
        title: 'GalaxiaLabs',
        theme: ThemeData(
          primarySwatch: Colors.purple,
        ),
        home: HomePage(),
      ),
    );
  }
}

    /*return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: HomePage(),
    );
  }
}
*/