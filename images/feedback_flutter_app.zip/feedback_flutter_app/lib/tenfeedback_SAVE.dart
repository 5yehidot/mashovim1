import 'package:flutter/material.dart';
//import 'package:share/share.dart';

import 'studentdbmanager.dart';
import 'categorydbmanager.dart';
import 'feedbackdbmanager.dart';
import 'tenfeedbackdbmanager.dart';

class MyTenFeedbackListPage extends StatefulWidget {
  @override
  _MyTenFeedbackListPageState createState() => _MyTenFeedbackListPageState();

}

class _MyTenFeedbackListPageState extends State<MyTenFeedbackListPage> {
  final DbTenFeedbackManager tenfeedbackdbmanager = DbTenFeedbackManager();
  final DbStudentManager studentdbmanager = DbStudentManager();
  final DbFeedbackManager feedbackdbmanager = DbFeedbackManager();
  final DbCategoryManager categorydbmanager = DbCategoryManager();
  final _tenmessageController = TextEditingController();
  final _tencategoryController = TextEditingController();
  final _tenrecipientnameController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  TenFeedbackobject tenfeedback;
  List<TenFeedbackobject> tenfeedbacklist;
  int updatetenIndex;

  List<String> _categoryoptions = <String>['', 'ש1', 'ש2', 'ש3', 'ש4'];
  String _categoryselected = '';

  List<String> _recipientoptions = <String>['', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  String _recipientselected = '';

  List<String> _studenttolist = <String>[];

  @override
  initState() {
    super.initState();

    // when loading your widget for the first time, loads animals from sqflite
    _loadStudentnames();
  }

  _loadStudentnames() async {
    // gets data from sqflite
    final loadStudentNames = await studentdbmanager.getStudentAsString('name');
    setState(() {
      // converts sqflite row data to List<String>, updating state
      _studenttolist = loadStudentNames.map((String value)  => ["name"] as String).toList();
    });
  }

  @override
    Widget build(BuildContext context) {
      double width = MediaQuery.of(context).size.width;

      return Scaffold(
        //appBar: AppBar(
          //title: Text('שליחת הודעות משוב'),
        //),
        body: Container(
          color: Colors.grey[100],
          height: double.infinity,
          width: double.infinity,
          child: ListView(children: <Widget>[
            Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(left: 25.0, top: 8.0, right: 25.0),
                    child: TextFormField(
                      keyboardType: TextInputType.multiline,
                      maxLines: null,
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                          labelText:
                          'משוב                                                   ',
                          hintText: 'הקלד/י הודעת משוב',
                          labelStyle: TextStyle(
                            color: Colors.purple, fontSize: 18, fontWeight: FontWeight.bold, )),
                      controller: _tenmessageController,
                      validator: (val) =>
                      val.isNotEmpty ? null : 'הודעה לא יכולה להשאר ריקה',
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: 25.0, top: 8.0, bottom: 25.0, right: 25.0),
                    child: FormField<String>(
                      builder: (FormFieldState<String> state) {
                        return InputDecorator(
                          decoration: InputDecoration(
                            icon: const Icon(Icons.vpn_key),
                            labelText: '                קטגוריה',
                            labelStyle: TextStyle(color: Colors.purple, fontSize: 18, fontWeight:  FontWeight.bold),

                          ),
                          isEmpty: _categoryselected == '',
                          child: new DropdownButtonHideUnderline(
                            child: new DropdownButton<String>(
                              value: _tencategoryController.text,
                              isDense: true,
                              onChanged: (String newValue) {
                                setState(() {
                                  _tencategoryController.text = newValue;
                                  _categoryselected = newValue;
                                  state.didChange(newValue);
                                });
                                print(_categoryselected);
                              },
//    items: _categoryidoptions.map((String value) {
                              items: _categoryoptions.map((String value) {
                                return new DropdownMenuItem<String>(
                                  value: value,
                                  child: new Text(value),
                                );
                              }).toList(),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: 25.0, top: 8.0, bottom: 25.0, right: 25.0),
                    child: FormField<String>(
                      builder: (FormFieldState<String> state) {
                        return InputDecorator(
                          decoration: InputDecoration(
                            labelText: 'בחר תלמיד',
                            errorText: state.hasError ? state.errorText : null,
                          ),
                          isEmpty: _tenrecipientnameController.text == '',
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: _tenrecipientnameController.text,
                              isDense: true,
                              onChanged: (String newValue) {
                                setState(() {
                                  //assessHed.asAnimal = newValue;

                                  _tenrecipientnameController.text = newValue;
                                  state.didChange(newValue);
                                });
                              },
                              items: _studenttolist.map((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                          ),
                        );
                      },
                      validator: (val) {
                        //return val != 'SUMMARY' ? 'DETAIL' : 'Please select Type';
                        return null;
                      },
                    ),
                    /*FormField<String>(
                      builder: (FormFieldState<String> state) {
                        return InputDecorator(
                          decoration: InputDecoration(
                            icon: const Icon(Icons.category),
                            labelText: '                תלמיד/ה',
                            labelStyle: TextStyle(color: Colors.purple, fontSize: 18, fontWeight:  FontWeight.bold),

                          ),
                          isEmpty: _recipientselected == '',
                          child: new DropdownButtonHideUnderline(
                            child: FutureBuilder(
                                future: studentdbmanager.getStudentList(),
                                builder: (context, snapshot) {
                                  return DropdownButton<String>(
                                      hint: Text("בחר/י תלמיד/ה"),
                                      value: _tenrecipientnameController.text,
                                      onChanged: (newValue) {
                                        setState(() {
                                          _tenrecipientnameController.text = newValue;
                                        });
                                      },
                                      items: snapshot.data.map((recipientoptions) =>
                                          DropdownMenuItem<String>(
                                            child: Text(recipientoptions),
                                            value: recipientoptions,
                                          )
                                      ).toList());
                                      //));
                                }),
                            *//*new DropdownButton<String>(
                              value: _tenrecipientnameController.text,
                              isDense: true,
                              onChanged: (String newValue) {
                                setState(() {
                                  _tenrecipientnameController.text = newValue;
                                  _recipientselected = newValue;
                                  state.didChange(newValue);
                                });
                              },
                              items: _recipientoptions.map((String value) {
                                *//**//*FutureBuilder( //_
                                future: studentdbmanager.getStudentList(),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
                                    studentlist = snapshot.data;
                                  }
                                }
                              )*//**//*

                                return new DropdownMenuItem<String>(
                                  value: value,
                                  child: new Text(value),
                                );
                              }).toList(),
                            ),*//*
                          ),
                        );
                      },
                    ),
*/
                  ),
                  RaisedButton(
                      textColor: Colors.white,
                      color: Colors.purple,
                      child: Container(
                        width: width * 0.95,
                        height: 80.0,
                        child: Text('עדכן', style: TextStyle(fontSize: 30.0),),
                        alignment: Alignment(0.0, 0.0),
                      ),
                      onPressed: () {
                        FocusScope.of(context).requestFocus(
                            new FocusNode()); // make soft keyboard disappeared
                        //Share.share(_tenmessageController.text);

                        setState(() {
                          _submitTenFeedback(context);
                        });
                      }),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      FutureBuilder(
                        future: tenfeedbackdbmanager.getTenFeedbackList(),
                        builder: (context, snapshot) {
                          //if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
                          if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
                            tenfeedbacklist = snapshot.data;
                            return ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount:
                              tenfeedbacklist == null ? 0 : tenfeedbacklist.length,
                              itemBuilder: (BuildContext context, int index) {
                                TenFeedbackobject ten = tenfeedbacklist[index];
                                //print(ten.tenmessage);
                                return Card(
                                  child: Row(
                                    children: <Widget>[
                                      Container(
                                          margin: const EdgeInsets.all(5.0),
                                          color: Colors.purple[100],
                                          width: width * 0.82,
                                          height: 120.0,
                                          child: FlatButton(
                                            // make a feedback card clickable
                                            onPressed: () {
                                              // Update input fields with current message, category and recipientname if user clicks on a feedback card
                                              _tenmessageController.text =
                                                  ten.tenmessage;
                                              _tencategoryController.text =
                                                  ten.tencategory;
                                              _tenrecipientnameController.text =
                                                  ten.tenrecipientname;

                                              tenfeedback =
                                                  ten; // Notify submitFeedback that feedback is not null
                                              updatetenIndex =
                                                  index; // Notify list builder which card needs update
                                            }, // onPressed
                                            child: Column(
                                              mainAxisAlignment:
                                              MainAxisAlignment.center,
                                              crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                              children: <Widget>[
                                                Text(
                                                  '${ten.tenmessage}',
                                                  style: TextStyle(
                                                      fontSize: 15,
                                                      color: Colors.blue),
                                                ),
                                                /*Text(
                                                '${fb.categoryname}',
                                                style: TextStyle(
                                                    fontSize: 15,
                                                    color: Colors.blue),
                                              ),*/
                                              ],
                                            ),
                                          )),
                                      /*
                                    IconButton(
                                      onPressed: () {
                                        //print('onpressed call deleteFeedback *** $index to be removed from feedback table in galaxia database');
                                        tenfeedback = ten;
                                        // Delete feedback record from feedback table in galaxia database
                                        tenfeedbackdbmanager
                                            .deleteTenFeedback(tenfeedback)
                                            .then((tenid) {
                                          setState(() {
                                            // refresh Feedback List cards;
                                            tenfeedbacklist.removeAt(index);
                                            _tenmessageController.clear();
                                            _tencategoryController.clear();
                                            _tenrecipientnameController.clear();
                                            //print('setstate removeAt update list after feedback $index removed from list');
                                          }); // setState
                                        });
                                      }, // onPressed
                                      icon: Icon(
                                        Icons.delete,
                                        color: Colors.red,
                                      ),
                                    )*/
                                    ],
                                  ),
                                );
                              }, // itemBuilder
                              reverse: true,
                            );
                          } // if
                          else {
                            if (snapshot.hasError) {
                              print('Error: ${snapshot.error}');
                            } else {
                              print('NOTTTTT snapshot.connectionState == ConnectionState.done && snapshot.data != null');
                              print('AND NOTTTTT snapshot.haserror');

                              return CircularProgressIndicator();
                            } // else
                          }
                          return CircularProgressIndicator();

                        }, // builder
                      ), // futureBuilder
                    ], // widget
                  ),
                ],
              ), // column
            ) // Form
          ] // widget
          ), // ListView
        ),
      ); // scaffold
    } //widget build

// Either add feedback record or update feedback record
    void _submitTenFeedback(BuildContext context) {
      if (_formKey.currentState.validate()) {
        if (tenfeedback == null) {
          //print("******tenfeedback null"); // Create a new tenfeedback record

          TenFeedbackobject ten = TenFeedbackobject(
            tenrecipientname: _tenrecipientnameController.text,
            tenrecipientphone: _tenmessageController.text,
            tenrecipientid: _tenmessageController.text,
            tengroup: _tenmessageController.text,
            tengroupid: _tenmessageController.text,
            tengrouptopic: _tenmessageController.text,
            tencategory:  _tencategoryController.text,
            tencategoryid: _tenmessageController.text,
            tenmessage: _tenmessageController.text,
            tenmessageid: _tenmessageController.text,
            tenstatement: _tencategoryController.text,
            tenstatementid: _tencategoryController.text,
            tensendername: _tencategoryController.text,
            tensenderid: _tencategoryController.text,
            tensenderphone: _tencategoryController.text);
          //print("****** tenfeedback null"); // Create a new tenfeedback record
          tenfeedbackdbmanager.insertTenFeedback(ten).then((tenid) => {
            // Insert new tenfeedback record to the tenfeedback table in galaxia database
            // and clear the input fields tenmessage, tencategory and tenrecipientname
            _tenmessageController.clear(),
            _tencategoryController.clear(),
            _tenrecipientnameController.clear(),
          });
        } else {
          //print("******tenfeedback NOT null");

          tenfeedback.tenmessage = _tenmessageController.text;
          tenfeedback.tencategory = _tencategoryController.text;
          tenfeedback.tenrecipientname = _tenrecipientnameController.text;
          //print(tenfeedback);

          // Update tenfeedback record in tenfeedback table in galaxia database after it was edited by the user

          tenfeedbackdbmanager.updateTenFeedback(tenfeedback).then((tenid) => {
            setState(() {
              tenfeedbacklist[updatetenIndex].tenmessage =
                  _tenmessageController.text;
              tenfeedbacklist[updatetenIndex].tencategory =
                  _tencategoryController.text;
              tenfeedbacklist[updatetenIndex].tenrecipientname =
                  _tenrecipientnameController.text;
            }),
            // Clear input fields
            _tenmessageController.clear(),
            _tencategoryController.clear(),
            _tenrecipientnameController.clear(),
          });
          // Clear feedback to allow for new feedback submit
          tenfeedback = null;
        } // end else feedback is not null
      } // if _formKey
    }
  } // _submitFeedback