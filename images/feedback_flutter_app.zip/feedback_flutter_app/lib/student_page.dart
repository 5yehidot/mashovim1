import 'package:flutter/material.dart';
//import 'package:share/share.dart';
//import 'package:flutter_sms/flutter_sms.dart';
import 'studentdbmanager.dart';

class MyStudentPage extends StatefulWidget {
  @override
  _MyStudentPageState createState() => _MyStudentPageState();
}

class _MyStudentPageState extends State<MyStudentPage> {
  final DbStudentManager studentdbmanager = DbStudentManager();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  Student student;
  List<Student> studentlist;
  int updateIndex;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text('רשימת תלמידים'),
      ),
      body: Container(
        color: Colors.grey[100],
        height: double.infinity,
        width: double.infinity,
        child: ListView(children: <Widget>[
          Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(left: 25.0, top: 8.0, right: 25.0),
                    child: TextFormField(
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                          labelText:
                              'שם התלמיד/ה                                                 ',
                          hintText: 'הקלד/י שם מלא',
                          labelStyle: TextStyle(
                              color: Colors.purple, fontSize: 18, fontWeight: FontWeight.bold)),
                      controller: _nameController,
                      validator: (val) =>
                          val.isNotEmpty ? null : 'שם לא יכול להשאר ריק',
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: 25.0, top: 8.0, bottom: 25.0, right: 25.0),
                    child: TextFormField(
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                          labelText:
                              'מספר טלפון נייד                                                                              ',
                          hintText: 'הקלד/י מספר טלפון נייד',
                          labelStyle: TextStyle(
                              color: Colors.purple, fontSize: 18, fontWeight: FontWeight.bold)),
                      controller: _phoneController,
                      validator: (val) => val.isNotEmpty
                          ? null
                          : 'מספר טלפון לא יכול להשאר ריק',
                    ),
                  ),
                  RaisedButton(
                      textColor: Colors.white,
                      color: Colors.purple,
                      child: Container(
                          width: width * 0.95,
                          height: 80,
                          child: Text('עדכן', style: TextStyle(fontSize: 30.0),),
                          alignment: Alignment(0.0, 0.0),
                      ),


                      onPressed: () {
                        FocusScope.of(context).requestFocus(
                            new FocusNode()); // make soft keyboard disappeared
                        //Share.share(_phoneController.text); //_phoneController.text
                        //_sendSMS('שלום, '+_nameController.text+', שאלת שאלה מעוררת השראה, '+_nameController.text, [_phoneController.text, ]);
                        setState(() {
                          print('Item was added');
                          _submitStudent(context);
                        });

                      }),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              FutureBuilder(
                    future: studentdbmanager.getStudentList(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
                        studentlist = snapshot.data;
                        return ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: studentlist == null ? 0 : studentlist.length,
                          itemBuilder: (BuildContext context, int index) {
                            Student st = studentlist[index];
                            print(st.name);
                            return Card(
                                  child: Row(
                                    children: <Widget>[
                                      Container(
                                          margin: const EdgeInsets.all(5.0),
                                          color: Colors.purple[100],
                                          width: width * 0.82,
                                          height: 60.0,
                                          child: FlatButton(
                                            // make a student card clickable
                                            onPressed: () {
                                              // Update input fields with current name and phone if user clicks on a student card
                                              _nameController.text = st.name;
                                              _phoneController.text = st.phone;
                                              student =
                                                  st; // Notify submitstudent that student is not null
                                              updateIndex =
                                                  index; // Notify list builder which card needs update
                                            }, // onPressed
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: <Widget>[
                                                Text(
                                                  'שם: ${st.name}',
                                                  style: TextStyle(
                                                      fontSize: 15,
                                                      color: Colors.blue),
                                                ),
                                                Text(
                                                  'טלפון: ${st.phone}',
                                                  style: TextStyle(
                                                      fontSize: 15,
                                                      color: Colors.purple),
                                                ),
                                              ],
                                            ),
                                          )),
                                      /*IconButton(
                                        onPressed: () {
                                          // Update input fields with current name and phone if user clicks on EDIT ICON
                                          _nameController.text = st.name;
                                          _phoneController.text = st.phone;
                                          student =
                                              st; // Notify submitstudent that student is not null
                                          updateIndex =
                                              index; // Notify list builder which card needs update
                                        }, // onPressed
                                        icon: Icon(
                                          Icons.edit,
                                          color: Colors.blueAccent,
                                        ),
                                      ),
                                      */IconButton(
                                        onPressed: () {
                                          //print('onpressed call deleteStudent *** $index to be removed from database');
                                          student = st;
                                          // student.stid = index;
                                          // studentdbmanager.deleteStudent(index);
                                          // Delete student from student table in galaxia database
                                          studentdbmanager
                                              .deleteStudent(student)
                                              .then((stid) {
                                            setState(() {
                                              // refresh StudentList cards;
                                              studentlist.removeAt(index);
                                              _nameController.clear();
                                              _phoneController.clear();
                                              //print('setstate removeAt update list after student $index removed from list');
                                            }); // setState
                                          });
                                        }, // onPressed
                                        icon: Icon(
                                          Icons.delete,
                                          color: Colors.red,
                                        ),
                                      )
                                    ],
                                  ),
                                );
                            }, // itemBuilder
                          reverse: true,
                        );
                      } // if
                      else {
                        if (snapshot.hasError) {
                          print('Error: ${snapshot.error}');
                        } else {
                          return CircularProgressIndicator();
                        } // else
                      }
                      return CircularProgressIndicator();

                    }, // builder
              ), // futureBuilder
            ], // widget
          ),
                ],
              ), // column
          ) // Form
        ] // widget
        ), // ListView
      ),
    ); // scaffold
  } //widget build
// Either add student record or update student record
  void _submitStudent(BuildContext context) {
    if (_formKey.currentState.validate()) {
//      if (student == null) {
      if (student == null) {
        //print("******student null"); // Create a new student record
        Student st =
            Student(name: _nameController.text, phone: _phoneController.text);
        //print('Student id is ${st.stid}');
        studentdbmanager.insertStudent(st).then((stid) => {
              // Insert new student record to the student table in galaxia database
              // and clear the input fields NAME and PHONE
              _nameController.clear(),
              _phoneController.clear(),
            });
      } else {
        //print("******student NOT null");

        student.name = _nameController.text;
        student.phone = _phoneController.text;
        // Update student record in student table in galaxia database after it was edited by the user

        studentdbmanager.updateStudent(student).then((stid) => {
              setState(() {
                studentlist[updateIndex].name = _nameController.text;
                studentlist[updateIndex].phone = _phoneController.text;
              }),
              // Clear input fields
              _nameController.clear(),
              _phoneController.clear(),
            });
        // Clear student to allow for new student submital
        student = null;
      } // end else student is not null
    } // if _formKey
  } // _submitStudent
/*  void _sendSMS(String message, List<String> recipents) async {
    String _result = await FlutterSms
        .sendSMS(message: message, recipients: recipents)
        .catchError((onError) {
      print(onError);
    });
    print(_result);
  }*/
} //class _MyHomePageState
