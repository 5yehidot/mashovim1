import 'package:flutter/material.dart';
//import 'package:share/share.dart';
import 'package:flutter_sms/flutter_sms.dart';
//import 'package:tuple/tuple.dart';

import 'studentdbmanager.dart';
import 'categorydbmanager.dart';
import 'feedbackdbmanager.dart';
import 'tenfeedbackdbmanager.dart';

/// method to send sms
/// opens up the SMS app only, recipients is a required field.
// works in emulator, you need to have a list of phone#s before using this method.
_sendSMS() async {
  List<String> recipients = ["0526954600"];
  String _result = await FlutterSms.sendSMS(message: "https://testdynamiclink.page.link/Zi7X", recipients: recipients).catchError((onError) {
    print(onError);
  });
  print(_result);
}

class MyTenFeedbackListPage extends StatefulWidget
{
  @override
  _MyTenFeedbackListPageState createState() => _MyTenFeedbackListPageState();
}

class _MyTenFeedbackListPageState extends State<MyTenFeedbackListPage>
{
  final DbTenFeedbackManager tenfeedbackdbmanager = DbTenFeedbackManager(); // table to store messages chosen for a specific student
  final DbCategoryManager categorydbmanager = DbCategoryManager(); // table of categories
  final DbFeedbackManager feedbackdbmanager = DbFeedbackManager(); // table of messages
  final DbStudentManager studentdbmanager = DbStudentManager(); // table of student names
  //final _tencategoryController = TextEditingController();
  //final _tenmessageController = TextEditingController();
  //final _tenrecipientnameController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  TenFeedbackobject tenfeedback;
  List<TenFeedbackobject> tenfeedbacklist;
  int updatetenIndex;

  List<String> _categorylist = <String>['בחר/י קטגוריה','ק1','ק2','ק3'];
  String _categoryselected = 'בחר/י קטגוריה';

  List<String> _feedbacklist = <String>['בחר/י משוב','מ1','מ2','מ3','מ4'];
  String _feedbackselected = 'בחר/י משוב';

  List<String> _studentnamelist = <String>['בחר/י תלמיד/ה','ש1','ש2','ש3','ש4'];
  String _recipientnameselected = 'בחר/י תלמיד/ה';
  List<String> _studentphonelist = <String>['Telephone number'];
  String _recipientphonenumber = 'Telephone number';

//  @override

  initState()
  {
    super.initState();
    // when loading your widget for the first time, load categories, feedback statements and recipient student names from sqflite
    _loadCategories();
    _loadFeedbackStatements();
    _loadStudentnames();

  }


Future<List> _loadCategories() async
  {
    // gets data from sqflite
    final loadCategories = await categorydbmanager.getCategoryList();
    int cLength = loadCategories.length;
    int clLength = _categorylist.length;
    //print(clLength);
    //print(_categorylist);
    _categorylist.removeRange(1,clLength);
    //print(_categorylist);
    for (var j = 0; j <= cLength-1; j++)
      {
        //print(cLength);
        //print(j);
        _categorylist.insert(j+1, loadCategories[j].categorystatement);
        //print(_categorylist);
      }
    //print(_categorylist);
    return _categorylist;
  }
 Future<List> _loadFeedbackStatements() async
  {
    if(_categoryselected == 'בחר/י קטגוריה'){return _feedbacklist;}
    else
      {
      // gets data from sqflite
      final loadfeedbackList = await feedbackdbmanager.getFeedbackList();
      int fLength = loadfeedbackList.length;
      int flLength = _feedbacklist.length;
      _feedbacklist.removeRange(1,flLength);
      //print(_feedbacklist);
      for (var k=0; k <= fLength-1; k++)
      {
        //print(fLength);
        //print(k);
        //print(loadfeedbackList[k].statement);
        if(loadfeedbackList[k].categoryname == _categoryselected)
        {
          _feedbacklist.insert(k+1, loadfeedbackList[k].statement);
        } else {_feedbacklist.insert(k+1, ' חסר משוב לקטגוריה שנבחרה  $k');}
        //print(_feedbacklist);
      }
      //print(_feedbacklist);
      return _feedbacklist;
  }

  }
Future<List>  _loadStudentnames() async
  {
    // gets data from sqflite
    final loadStudentNames = await studentdbmanager.getStudentList();
    int sLength = loadStudentNames.length;
    int slLength = _studentnamelist.length;
    _studentnamelist.removeRange(1,slLength);
    //print(_studentnamelist);

    for (var i=0; i<=sLength-1; i++)
    {
      //print(sLength);
      //print(i);
      //print(loadStudentNames[i].name);
      _studentnamelist.insert(i+1, loadStudentNames[i].name);
      //print(_studentnamelist);
    }
    //print(_studentnamelist);
    return _studentnamelist;
  }

  Future<String> _loadStudentphone() async
  {
    if (_recipientnameselected == 'בחר/י תלמיד/ה') {
      _recipientphonenumber = '000';
      return _recipientphonenumber;
    }
    else {
      // gets data from sqflite
      final loadphoneList = await studentdbmanager.getStudentList();
      int pLength = loadphoneList.length;
      print(pLength);
      print('phone is $_recipientphonenumber');
      for (var l = 0; l <= pLength - 1; l++) {
        print('selected name $_recipientnameselected');
        print(loadphoneList[l].name);
        if (loadphoneList[l].name == _recipientnameselected) {
          _recipientphonenumber = loadphoneList[l].phone;
          print('matched number $_recipientphonenumber');
          return _recipientphonenumber;
          //_feedbacklist.insert(k + 1, loadfeedbackList[k].statement);
          //_studentphonelist.insert(i + 1, loadStudentNames[i].phone);
        } /*else {
          _recipientphonenumber = '111';
          return _recipientphonenumber;
        }*/
      }
      return _recipientphonenumber;
    }
  }


    void _sendSMS(String message, List<String> recipents) async {
    String _result = await FlutterSms.sendSMS(message: message, recipients: recipents)
        .catchError((onError) {
      print(onError);
    });
    print(_result);
  }
  @override
  Widget build(BuildContext context)
  {

    double width = MediaQuery.of(context).size.width;
    _loadCategories();
    _loadFeedbackStatements();
    _loadStudentnames();

    return Scaffold(
//      backgroundColor: Colors.blue[900],
      body: Container(
        color: Colors.grey[100],
        height: double.infinity,
        width: double.infinity,
        child: ListView
        (
          children: <Widget>
          [
            Form
            (
              key: _formKey,
              child: Column
              (
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>
                [
                  Padding(
                  padding: EdgeInsets.only(
                      left: 10.0, top: 0.0, bottom: 0.0, right: 20.0),
                  child: Center(
                    child: FormField<String>(
                      builder: (FormFieldState<String> state) {
                        //print(_categoryselected);
                        //print(_feedbackselected);
                        //print(_recipientnameselected);
                        return InputDecorator(
                          decoration: InputDecoration(
                            icon: const Icon(Icons.category),
                            labelText: '',
                            labelStyle: TextStyle(color: Colors.purple, fontSize: 18, fontWeight:  FontWeight.bold),
                          ),
                          isEmpty: _categoryselected == 'בחר/י קטגוריה',
                          child: new DropdownButtonHideUnderline(
                            child: Center(
                              child: new DropdownButton<String>
                              (
                                value: _categoryselected,
                                isDense: false,
                                items: _categorylist.map((String value)
                                {
                                  return new DropdownMenuItem<String>(
                                    value: value,
                                    child: new Text(value),
                                  );
                                }).toList(),
                                onChanged: (String newValue) {
                                  setState(() {
                                    _loadFeedbackStatements();//.then((_feedbacklist) {
                                      // Run extra code here
                                      print(_feedbacklist);
                                      print('new category value $newValue');
                                      _categoryselected = newValue;
                                      state.didChange(newValue);
                                    //});

                                  });
                                },
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: 10.0, top: 0.0, bottom: 0.0, right: 20.0),
                    child: Center(
                      child: FormField<String>(
                        builder: (FormFieldState<String> state) {
                          return InputDecorator(
                            decoration: InputDecoration(
                              icon: const Icon(Icons.feedback),
                              labelText: '',
                              labelStyle: TextStyle(color: Colors.purple, fontSize: 18, fontWeight:  FontWeight.bold),
                            ),
                            isEmpty: _feedbackselected == 'בחר/י משוב', // was '' 15 Apr 2020
                            child: new DropdownButtonHideUnderline(
                              child: Center(
                                child: new DropdownButton<String>
                                  (
                                  value: _feedbackselected,
                                  isDense: false,
                                  items: _feedbacklist.map((String value)
                                  {
                                    return new DropdownMenuItem<String>(
                                      value: value,
                                      child: new Text(value),
                                    );
                                  }).toList(),
                                  onChanged: (String newValue) {
                                    setState(() {
                                      print('new message value $newValue');
                                      _feedbackselected = newValue;
                                      state.didChange(newValue);
                                    });
                                  },
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: 10.0, top: 0.0, bottom: 0.0, right: 20.0),
                    child: Center(
                      child: FormField<String>
                      (
                        builder: (FormFieldState<String> state)
                        {
                          return InputDecorator(
                          decoration: InputDecoration(
                            icon: const Icon(Icons.person),
                            labelText: '',
                            labelStyle: TextStyle(color: Colors.purple, fontSize: 18, fontWeight:  FontWeight.bold),
                          ),
                          isEmpty: _recipientnameselected == 'בחר/י תלמיד/ה',
                          child: new DropdownButtonHideUnderline(
                            child: Center(
                              child: new DropdownButton<String>
                              (
                                value: _recipientnameselected,
                                isDense: false,
                                items: _studentnamelist.map((String value)
                                {
                                  return new DropdownMenuItem<String>(
                                    value: value,
                                    child: new Text(value),
                                  );
                                }).toList(),
                                onChanged: (String newValue){
                                  setState(() {
                                    print('new student name value $newValue');
                                    _recipientnameselected = newValue;
                                    _loadStudentphone();

                                    state.didChange(newValue);
                                  });
                                },
                              ),
                            ),
                          ),
                        );
                        },
                      ),
                    ),
                  ),
                ]
              )
            ),
                RaisedButton(
                    textColor: Colors.white,
                    color: Colors.purple,
                    child: Container(
                      width: width * 0.95,
                      height: 80.0,
                      child: Text('עדכן', style: TextStyle(fontSize: 30.0),),
                      alignment: Alignment(0.0, 0.0),
                    ),
                    onPressed: () {
                      FocusScope.of(context).requestFocus(
                          new FocusNode()); // make soft keyboard disappeared
                      String sendMessage = ' כל הכבוד ${_recipientnameselected}, ${_feedbackselected}';
                      print('about to send $sendMessage to $_recipientphonenumber');
                      _sendSMS(sendMessage, [_recipientphonenumber, "0526954600"]);
                      //_sendSMS(_feedbackselected, [_recipientphonenumber, "0526954600"]);
                      //Share.share(' כל הכבוד ${_recipientnameselected}, ${_feedbackselected}');

                      setState(() {
                        _submitTenFeedback(context);

                      });
                    }),
                Column
                (
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>
                  [
                    FutureBuilder
                    (
                      future: tenfeedbackdbmanager.getTenFeedbackList(),
                      builder: (context, snapshot) {
                        //if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
                        if (snapshot.connectionState == ConnectionState.done && snapshot.data != null)
                        {
                          tenfeedbacklist = snapshot.data;
                          return ListView.builder
                          (
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount:
                            tenfeedbacklist == null ? 0 : tenfeedbacklist.length,
                            itemBuilder: (BuildContext context, int index)
                            {
                              TenFeedbackobject ten = tenfeedbacklist[index];
                              //print(ten.tenmessage);
                              return Card
                              (
                                child: Row
                                (
                                  children: <Widget>
                                  [
                                    Container
                                    (
                                      margin: const EdgeInsets.all(5.0),
                                      color: Colors.purple[100],
                                      width: width * 0.82,
                                      height: 120.0,
                                      child: FlatButton
                                      (
                                          // make a feedback card clickable
                                        onPressed: ()
                                        {
                                          print('לחיצה על כרטיס');
                                          // print(ten.tenmessage);
                                          /*_categoryselected = ten.tencategory;
                                          _feedbackselected = ten.tenmessage;
                                          _recipientnameselected = ten.tenrecipientname;
                                          print(_feedbackselected);
                                          print(_categoryselected);
                                          print(_recipientnameselected);*/

                                          // Update input fields with current message, category and recipientname if user clicks on a feedback card
                                          //_feedbackselected = ten.tenmessage;
                                          //_categoryselected = ten.tencategory;
                                          //_recipientnameselected = ten.tenrecipientname;
                                          tenfeedback = ten; // Notify submitFeedback that feedback is not null
                                          updatetenIndex = index; // Notify list builder which card needs update
                                        }, // onPressed
                                        child: Column
                                        (
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          children: <Widget>
                                          [
                                            Text
                                            (
                                              '${ten.tenmessage}',
                                              style: TextStyle
                                              (
                                                fontSize: 15,
                                                color: Colors.blue
                                              ),
                                            ),
                                            Text
                                              (
                                              '${ten.tencategory}',
                                              style: TextStyle
                                                (
                                                  fontSize: 15,
                                                  color: Colors.blue
                                              ),
                                            ),
                                            Text
                                              (
                                              '${ten.tenrecipientname}',
                                              style: TextStyle
                                                (
                                                  fontSize: 15,
                                                  color: Colors.blue
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    ),
                                    IconButton(
                                      onPressed: () {
                                        tenfeedback = ten;
                                        tenfeedbackdbmanager
                                            .deleteTenFeedback(tenfeedback)
                                            .then((tenid) {
                                          setState(() {
                                            // refresh tenFeedbackList cards;
                                            tenfeedbacklist.removeAt(index);
                                            //_tenmessageController.clear();
                                            /*_categoryselected = 'בחר/י קטגוריה';
                                            _feedbackselected = 'בחר/י משוב';
                                            _recipientnameselected = 'בחר/י תלמיד/ה';*/
                                          }); // setState
                                        });
                                      }, // onPressed
                                      icon: Icon(
                                        Icons.delete,
                                        color: Colors.red,
                                      ),
                                    )
                                  ],
                                ),
                              );
                            }, // itemBuilder
                            reverse: true,
                          );
                        } // if
                        else
                        {
                          if (snapshot.hasError)
                          {
                            print('Error: ${snapshot.error}');
                          } else
                          {
                            // print('NOTTTTT snapshot.connectionState == ConnectionState.done && snapshot.data != null');
                            // print('AND NOTTTTT snapshot.haserror');

                            return CircularProgressIndicator();
                          } // else
                        }
                        return CircularProgressIndicator();

                      }, // builder
                    ),
                  ], // widget
                ),
              ],
            ),
          ),
        );
  }

// Either add feedback record or update feedback record
  void _submitTenFeedback(BuildContext context)
  {
    if (_formKey.currentState.validate())
    {
      if (tenfeedback == null)
      {
        //print("******tenfeedback null"); // Create a new tenfeedback record

        TenFeedbackobject ten = TenFeedbackobject(
            tenrecipientname: _recipientnameselected,
            tenrecipientphone: 'null recipient phone',
            tenrecipientid: 'null recipient id',
            tengroup: 'null group',
            tengroupid: 'null group id',
            tengrouptopic: 'null group topic',
            tencategory:  _categoryselected,
            tencategoryid: 'null category id',
            tenmessage: _feedbackselected,
            tenmessageid: 'null message id',
            tenstatement: _feedbackselected,
            tenstatementid: 'null statement id',
            tensendername: 'null sender name',
            tensenderid: 'null sender id',
            tensenderphone: 'null sender phone');
        // Create a new tenfeedback record
        tenfeedbackdbmanager.insertTenFeedback(ten).then((tenid) =>
        {
          // Insert new tenfeedback record to the tenfeedback table in galaxia database
          // and clear the input fields tenmessage, tencategory and tenrecipientname
        /*_categoryselected = 'בחר/י קטגוריה',
        _feedbackselected = 'בחר/י משוב',
        _recipientnameselected = 'בחר/י תלמיד/ה',*/
          //_tenmessageController.clear(),
          //_tencategoryController.clear(),
          //_tenrecipientnameController.clear(),
        });
        /*_categoryselected = 'בחר/י קטגוריה';*/

      } else
      {
        tenfeedback.tenmessage = _feedbackselected;
        tenfeedback.tencategory = _categoryselected;
        tenfeedback.tenrecipientname = _recipientnameselected;
        // Update tenfeedback record in tenfeedback table in galaxia database after it was edited by the user
        tenfeedbackdbmanager.updateTenFeedback(tenfeedback).then((tenid) =>
        {
          setState(() {
            tenfeedbacklist[updatetenIndex].tenmessage =
                _feedbackselected;
            tenfeedbacklist[updatetenIndex].tencategory =
                _categoryselected;
            tenfeedbacklist[updatetenIndex].tenrecipientname =
                _recipientnameselected;
          }),
          // Clear input fields
          //_tenmessageController.clear(),
          //_tencategoryController.clear(),
          /*_categoryselected = 'בחר/י קטגוריה',
          _feedbackselected = 'בחר/י משוב',
          _recipientnameselected = 'בחר/י תלמיד/ה',*/
        });
        // Clear feedback to allow for new feedback submit
        tenfeedback = null;
      } // end else feedback is not null
    } // if _formKey
  } // void _submitTenFeedback
} // _submitFeedback