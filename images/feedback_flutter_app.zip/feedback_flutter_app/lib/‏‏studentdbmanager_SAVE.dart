import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbStudentManager {
  Database _studentdatabase;

  Future openDb() async {
    if (_studentdatabase == null){
      print("studentdatabase is null");
      _studentdatabase = await openDatabase(
          join(await getDatabasesPath(), "studentdatabase.db"),
          version: 1, onCreate: (Database db, int version) async {
        await db.execute("CREATE TABLE student(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)");
      });
      /*var databasesPath = await getDatabasesPath();
      String path = join(databasesPath, 'studentdatabase.db');

// Delete the database
      await deleteDatabase(path);*/
    } else {
      print("studentdatabase is not null **** did not delete database");
      return _studentdatabase;
    }
  }

  Future<int> insertStudent(Student student) async {
    await openDb();
    return await _studentdatabase.insert('student', student.toMap());

  }

  Future<List<Student>> getStudentList() async {
    await openDb();
    final List<Map<String, dynamic>> maps = await _studentdatabase.query('student');
    return List.generate(maps.length, (i){
      return Student(
        id: maps[i]['id'],
        name: maps[i]['name'],
        phone: maps[i]['phone'],
      );
    });

  }
  Future<int> updateStudent(Student student) async {
    await openDb();
    return await _studentdatabase.update(
        'student',
        student.toMap(),
        where: 'student.id = ?',
        whereArgs: [student.id]);

  }

  Future<int> deleteStudent(Student student) async
  {
    print('Delete function fff ${student.id}');
    await openDb();
    return _studentdatabase.delete('student', where: 'student.id = ?', whereArgs: [student.id]);
  }

}

class Student {
  int id;
  String name;
  String phone;
  Student({@required this.name, @required this.phone, @required this.id});
  Map<String, dynamic> toMap(){
    return {'name': name, 'phone': phone, 'id': id};
  }
}
